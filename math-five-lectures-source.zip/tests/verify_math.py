import sympy as s
import json
from pathlib import Path
x,y,z,t,r,R=s.symbols('x y z t r R',real=True)
checks={}
def check(name,a,b):
 checks[name]=s.simplify(a-b)==0
A=s.Matrix([[1,1,1],[1,0,1],[1,1,1]])
l=s.symbols('lambda')
check('PDF 4.1 characteristic polynomial',(A-l*s.eye(3)).det(),-l*(l*l-2*l-2))
B=s.Matrix([[0,-1,1],[-1,0,1],[1,1,0]])
p=s.Matrix.hstack(s.Matrix([-1,1,0])/s.sqrt(2),s.Matrix([1,1,2])/s.sqrt(6),s.Matrix([-1,-1,1])/s.sqrt(3))
checks['PDF 4.6 orthonormal diagonalization']=(s.simplify(p.T*B*p)==s.diag(1,1,-2) and s.simplify(p.T*p)==s.eye(3))
check('PDF 3.13 ode',s.diff(s.exp(x)/2+s.exp(-x),x)+s.exp(x)/2+s.exp(-x),s.exp(x))
Y=((x-2)**2+1)/2
check('PDF 3.14 original second order',1+s.diff(Y,x)**2,2*Y*s.diff(Y,x,2))
Y=s.exp(x)*(x*s.log(x)-x)
check('PDF 3.18 nonhomogeneous',s.diff(Y,x,2)-2*s.diff(Y,x)+Y,s.exp(x)/x)
check('PDF 5.1 triangle integral',s.integrate(s.integrate(x,(y,0,1-x)),(x,0,1)),s.Rational(1,6))
check('PDF 5.3 sliced volume',s.pi*s.integrate(z*s.exp(-z*z),(z,0,1)),s.pi/2*(1-s.exp(-1)))
check('PDF 5.4 spherical volume',4*s.pi*s.integrate((1-r*r)*r*r,(r,0,1)),8*s.pi/15)
# Directly verify the antiderivative and bounds for the first-type line integral.
F=(1+s.exp(2*x))**s.Rational(3,2)/3
check('PDF 5.5 line integral primitive',s.diff(F,x),s.exp(2*x)*s.sqrt(1+s.exp(2*x)))
check('PDF 5.5 line integral bounds',F.subs(x,1)-F.subs(x,0),((1+s.exp(2))**s.Rational(3,2)-2*s.sqrt(2))/3)
check('PDF 5.6 oriented circle arc',s.integrate(s.cos(t)**2+s.sin(t)**2,(t,0,s.pi/2)),s.pi/2)
check('least squares worked example',sum((yy-(s.Rational(1,2)*xx+s.Rational(7,6)))**2 for xx,yy in [(0,1),(1,2),(2,2)]),s.Rational(1,6))
checks['PDF 2.6 inverse']=s.Matrix([[1,1,0],[0,1,1],[1,0,1]]).inv()==s.Matrix([[1,-1,1],[1,1,-1],[-1,1,1]])/2
print(json.dumps(checks,indent=2))
assert all(checks.values())
Path(__file__).with_name('math-results.json').write_text(json.dumps(checks,indent=2))
