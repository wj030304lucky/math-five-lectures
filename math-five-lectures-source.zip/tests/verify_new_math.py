"""Independently verify all new numeric checkpoints by symbolic arithmetic/calculus."""
import sys,math,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from practice_upgrade import pair
import sympy as s
x,y,z,t,h,lam=s.symbols('x y z t h lam',real=True)

def oracle(k):
    mat=s.Matrix([[1,k],[0,1]]); b=s.Matrix([[1,0],[k,1]])
    eig=s.Matrix([[k,1],[1,k]])
    p=s.Matrix([[1,0,1],[0,1,k],[1,1,s.Symbol('m')]])
    q1=s.limit((x*x-k*k)/(x-k),x,k)
    q2=s.limit((s.sqrt(k*k+x)-k)/x,x,0)
    return {
    'limit':(q1,q2),
    'continuous':(s.limit(((k+h)**2-k*k)/h,h,0),k*k-s.diff(x*x,x).subs(x,k)*k),
    'rules':(s.diff((k*x+1)**3,x).subs(x,1),s.diff(x**k*s.log(x),x).subs(x,1)),
    'primitive':(s.integrate(k*x**(k-1),(x,0,1))+2,s.integrate(2*x+k,(x,0,2))+1),
    'definite':(s.integrate(2*x,(x,1,k)),s.diff((k*x)**3/3-s.Rational(1,3),x).subs(x,1)),
    'substitution':(s.integrate(k*x**(k-1)*(1+x**k),(x,0,1)),s.simplify(s.integrate(k*x**(k-1)/(1+x**k),(x,0,1))/s.log(2))),
    'parts':(s.integrate(x**k*s.log(x),(x,0,1)),s.Rational(1,k*k)),
    'vector':((s.Matrix([k,1,-1])+s.Matrix([1,k,1])).dot(s.Matrix([k+1,k+1,0])),-1),
    'dot':(s.Matrix([k,1]).dot(s.Matrix([1,-k])),s.Matrix([k,1]).dot(s.Matrix([1,1]))/s.Integer(2)),
    'cross':(s.Matrix([k,0,0]).cross(s.Matrix([0,2,0])).norm()/2,s.Matrix([k,0,0]).dot(s.Matrix([0,2,0]).cross(s.Matrix([0,0,3])))),
    'matrix':((mat*b)[0,0],(mat*b-b*mat)[0,0]),
    'rotation':(mat.inv()[0,1],(s.Matrix([[0,-1],[1,0]])*s.Matrix([k,1]))[0]),
    'det':(s.Matrix([[k,1],[2,k]]).det(),(2*s.eye(k)).det()*2),
    'block':(s.diag(k,s.Matrix([[2,1],[1,1]])).det(),s.Matrix([[k,1],[0,1]]).inv()[0,1]),
    'row':(s.solve([x+y-k-2,2*x+y-2*k-2],[x,y])[x],s.solve(x+k*2+2-1,x)[0]),
    'rank':(s.Matrix([[1,k,0],[2,2*k,0],[0,0,1]]).rank(),s.solve(p.det(),s.Symbol('m'))[0]),
    'existence':((k+2)-s.eye(k).rank(),int(s.Matrix([[1,1,k],[2,2,2*k+1]]).rank()==s.Matrix([[1,1],[2,2]]).rank())),
    'plane':(s.solve(k+z,z)[0],(2-t).subs(t,s.solve(k*t-2*k,t)[0])),
    'surfaces':(s.sqrt(k*k+1-1),s.simplify(k*(4*s.pi)/s.pi)),
    'dependence':(s.solve([x-k,x+y-k-2],[x,y])[y],s.Matrix([[1,k,0],[0,0,1]]).rank()),
    'structure':(s.solve(x+k,x)[0],s.solve(x+2*k-1,x)[0]),
    'separable':(s.log(s.exp(k)),(k/(1+k*x)).subs(x,1)),
    'linearode':(s.solve(1+x,x)[0],s.diff(2*s.exp(-k*x),x).subs(x,0)),
    'reduce':(sum(s.solve(lam*lam-(k+1)*lam+k,lam)),s.diff(s.cos(k*x),x,2).subs(x,0)),
    'nonhom':(s.solve(2+x-k,x)[0],s.simplify(((k*k-1)*s.exp(k*x))/(s.diff(s.exp(k*x),x,2)-s.exp(k*x)))),
    'eigen':(s.Matrix([[k,1],[0,k+1]]).trace(),(eig*s.Matrix([1,-1]))[0]),
    'similar':((s.diag(k,2)**2).trace(),s.diag(1,k).inv().det()),
    'quadratic':(s.diff(x*x+2*k*x*y+y*y,x,y)/2,int(all(v>0 for v in s.diag(k,2).eigenvals()))),
    'systems':(s.diff(2*s.exp(-k*t),t).subs(t,0),sum(v>0 for v in (-1,k))),
    'partial':(s.diff(x*x*y+k*y,x).subs({x:1,y:2}),s.diff(x**k*y*y,x,y).subs({x:1,y:1})),
    'implicit':(-s.Rational(1,k),s.diff(k/x,x,2).subs(x,1)),
    'gradient':(s.Matrix([k,2]).dot(s.Matrix([0,1])),s.Matrix([k,1]).norm()**2),
    'extrema':(s.hessian(k*x*x+y*y,(x,y)).det(),s.hessian(k*x*x-y*y,(x,y)).det()),
    'lagrange':((x*x+(2*k-x)**2).subs(x,k),(x*(2*k-x)).subs(x,k)),
    'regression':((k+1-1)/1,(k-1)**2),
    'double':(s.integrate(s.integrate(x,(y,0,1)),(x,0,k)),s.integrate(s.integrate(x*y,(y,0,k)),(x,0,1))),
    'polar':(2*s.integrate(x,(x,0,k)),2*s.integrate(x**3,(x,0,k))),
    'triple':(s.integrate(s.integrate(s.integrate(1,(z,0,1)),(y,0,1)),(x,0,k)),4*s.integrate(x*x,(x,0,k))),
    'lineintegral':(s.integrate(s.sqrt(3**2+4**2),(t,0,k)),s.integrate(2*t,(t,0,k))),
    'green':(s.integrate(s.integrate(1,(y,0,1)),(x,0,k)),-s.integrate(s.integrate(2,(y,0,1)),(x,0,k))),
    'surfaceintegral':(s.Matrix([-k,0,1]).norm()**2,s.Matrix([0,0,k]).dot(s.Matrix([0,0,-1]))),
    'gauss':(s.diff(k*x,x)*s.Rational(4,3),s.diff(k*x,x)-s.diff(-k*y,y)),
    'series':(s.summation(s.Rational(1,k)**s.Symbol('n'),(s.Symbol('n'),0,s.oo)),int(k>1)),
    'taylor':(s.diff(s.exp(x),x,k).subs(x,0)/s.factorial(k),sum(s.Rational(1,2)**j for j in range(k+1)))
    }

checked=0
for k in (2,3,5):
    for id,expected in oracle(k).items():
        items=pair(id,k)
        for i,v in enumerate(expected):
            target=float(s.N(v));actual=items[i]['answer']
            assert math.isclose(target,actual,rel_tol=1e-10,abs_tol=1e-10),(id,k,i,target,actual)
            checked+=1
result=dict(checked=checked,passed=True)
Path(__file__).with_name('new-math-results.json').write_text(json.dumps(result))
print(json.dumps(result))
